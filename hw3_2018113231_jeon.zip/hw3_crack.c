#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

volatile long balance = 0;
long maxTry = 100;
long maxThreads = 100;

void *deposit(void *args);
void *withdraw(void *args);
long swap(long x);      //To make the errors, swap the balance many times.

pthread_mutex_t lck;    //define mutex

int main(int argc, char *argv[])  {   

        pthread_t dep[100], wit[100];   //deposit pthread, withdraw pthread.
        int retval;
        int l;

        if (argc <= 1) {
                printf("You should input 3 argument to implement\n");
                printf("Try again. ./filename.out {balance} {MaxTry} {MaxThreads}\n");
                exit(1);
        }
        if (argc >= 2) {
                balance = atoi(argv[1]);
                maxTry = atoi(argv[2]);
        }

        if (argc >3){
                maxThreads = atoi(argv[3]);
                printf("Start Balance -> %ld, MaxTry -> %ld, MaxThreads -> %ld\n", balance, maxTry, maxThreads);
        }
        else{
                printf("You need to input max thread.\n");
                exit(1);
        }
        //create the pthread to access the global variable.
        for (l=0;l<maxThreads;l++){
                pthread_create( &dep[l], NULL, deposit, NULL);
                pthread_create( &wit[l], NULL, withdraw, NULL);
        }
        //wait the function to quit
        for (l=0;l<maxThreads;l++){
                pthread_join( dep[l], NULL);
                pthread_join( wit[l], NULL);
        }
 
        printf("Final Balance -> %ld\n", balance);

        return 0;
}

void *deposit(void *args)
{
        long i;

        for(i = 0; i < maxTry; i++)
        {
                balance = balance + i;
                balance = swap(balance);
        }
        pthread_exit(0);
}


void *withdraw(void *args)
{
        long i;
        
        for(i = 0; i < maxTry; i++)
        {
                balance -= i;
                balance = swap(balance);

        }
        pthread_exit(0);
}


long swap(long x)
{       
        long tmp;
        int l;
        //To make the error, swap the balance several times.
        for(l=0; l<100; l++){
                tmp = x;
                x = tmp;
        }
        return x;
}