#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

volatile int gval = 0; //To easily make error , give "volatile" property to gval.
int maxTry = 100;
int maxThreads = 100;

void *deposit(void *args);
void *withdraw(void *args);
int swap(int x);      //To make the errors, swap the gval many times.

pthread_mutex_t lck;    //define mutex

int main(int argc, char *argv[])  {   
        pthread_t dep[100], wit[100];   //deposit pthread, withdraw pthread.
        int retval;
        int l;
        if (argc <= 1) {
                printf("You shoud input 3 argument to implement\n");
                printf("Try again. ./{filename}.out {gval} {MaxTry} {MaxThreads}\n");
                exit(1);
        }
        if (argc >= 2) {
                gval = atoi(argv[1]);
                maxTry = atoi(argv[2]);
        }
        if (argc >3){
                maxThreads = atoi(argv[3]);
                printf("Start gval -> %d, MaxTry -> %d, MaxThreads -> %d\n", gval, maxTry, maxThreads);
        }
        else{
                maxThreads = 1;
                printf("Start gval -> %d, MaxTry -> %d, MaxThreads -> %d\n", gval, maxTry, maxThreads);
                exit(1);
        }
        //create the pthread to access the global variable.
        for (l=0;l<maxThreads;l++){
                pthread_create( &dep[l], NULL, deposit, NULL);
                pthread_create( &wit[l], NULL, withdraw, NULL);
        }
        //wait the function to quit
        for (l=0;l<maxThreads;l++){
                pthread_join( dep[l], NULL);
                pthread_join( wit[l], NULL);
        }
        printf("Final gval -> %d\n", gval);

        return 0;
}

void *deposit(void *args)
{
        int i;
        int *dep = (int *)(args);

        for(i = 0; i < maxTry; i++)
        {
                gval = gval + i;
                gval = swap(gval);
        }
        pthread_exit(0);
}

void *withdraw(void *args)
{
        int i;
        int *wit = (int *)(args);
        for(i = 0; i < maxTry; i++)
        {
                gval -= i;
                gval = swap(gval);
        }
        pthread_exit(0);
}


int swap(int x)
{       
        int tmp;
        //To make the error, swap the gval several times.
        for(int l=0; l<100; l++){
                tmp = x;
                x = tmp;
        }
        return x;
}